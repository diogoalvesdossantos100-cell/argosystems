# Argo Systems — Design System

> *Infraestrutura operacional crítica para sistemas hospitalares modernos.*

This system defines the institutional identity for **Argo Systems** — a clinical-intelligence company whose flagship platform, **AURIA**, detects sepsis and other critical events in the ICU before they become lethal.

## Brand architecture

| | |
|---|---|
| **Company / brand** | **Argo Systems** |
| **Platform name** | AURIA *(umbrella for all clinical modules)* |
| **Modules** | NoSepsis · NoPAV · NoDelirium · NoReação · Gestão de Leito · Escala de Enfermagem · NoMaster |
| **Site URL** | argosystems.com.br |

The website, app and product surfaces all carry the **Argo Systems** mark. AURIA is the named platform inside the offering — referenced in body copy and used as a sub-brand label, never as the lead identity. Modules sit underneath AURIA as productized capabilities.

> Think Stripe → "Stripe is the company; Stripe Payments is the platform; Connect, Radar, Atlas are the modules." Same pattern, hospital edition.

## Identity v2 — repositioned

The v1 identity (triangular A, cyan baseline accent) read as *startup tech / gamer* — wrong vocabulary for software running inside an ICU. v2 is a deliberate reset toward **Palantir / Anduril / Stripe / Linear** territory: monochromatic, hairline-precise, quietly authoritative.

**Mark.** A stencil "A" with a precise apex gap. Two diagonals + a horizontal crossbar, no resolution at the apex — reads as observation / aperture / clinical instrument without being a literal AI cliché. Single stroke weight (2.6 units on a 56-unit grid), square caps, miter joins. The same glyph scales from 16px favicon to printed cover with zero modification.

**Wordmark.** "ARGO" set in Geist 500, 0.20em tracking, with "SYSTEMS" in Geist Mono 400 at 0.32em tracking as a caption underneath. Two tiers, calibrated weights, one optical line. The mono caption is what gives it the *infrastructure* feel — same trick Anduril and Datadog use.

**Lockups.**
- `argo-wordmark.svg` — primary horizontal (mark · divider · ARGO + SYSTEMS caption)
- `argo-wordmark-stacked.svg` — vertical, mark above wordmark
- `argo-wordmark-single.svg` — one-line compact for tight spaces
- `argo-monogram.svg` — boxed mark, for app icons and avatars
- `argo-mark.svg` — symbol only, transparent
- `argo-wordmark-accent.svg` — same as primary but the crossbar is `violet-500`. Use sparingly.
- `favicon.svg` — 32-grid mark on rounded square ink-0

**Platform sub-brand.**
- `auria-wordmark.svg` — "AURIA · PLATFORM" used inside content when introducing the platform by name.
- `auria-platform-label.svg` — compact label-tag with an aperture-style dot, for badges and capsules.

AURIA is *always* presented in a context that carries the Argo Systems mark; never as a standalone logo replacing Argo. Treat it like AWS treats EC2 — the offering has a name, the company has the logo.

**Color.** Identity is **monochromatic by default** — `#F2F3F8` on `#05060B`. Violet (`#7C5CFF`) is an **optional accent** applied only to the crossbar of the mark, and only in marketing surfaces. Never in product chrome. The old cyan baseline accent is retired.

**Clear space.** Minimum clear space around the mark equals the cap height of the A (≈ 35 units of the 56-unit grid). Never crowd, never tint, never rotate. Lockups never reflow — if the horizontal doesn't fit, drop to the stacked.

The visual target is set in one sentence:

> **"This company looks much bigger than it actually is."**

Stripe-grade micro‑typography. Linear-sharp 1px borders. Vercel layered geometry. Palantir / Anduril operational density. Apple cinematic restraint. Raycast spotlight precision.

---

## What this is

Argo Systems is the parent brand. **AURIA** is the modular platform. Seven modules ship on AURIA today:

| Module | Status | Purpose |
|---|---|---|
| **NoSepsis** | Active · flagship | Predictive sepsis detection in the ICU (RHPM risk queue, actionable alerts, executive report) |
| **NoPAV** | Active | Prevention of Ventilator-Associated Pneumonia; bundle compliance |
| **NoDelirium** | Active | Continuous delirium screening in critical patients |
| **NoReação** | Active | Real-time monitoring of transfusion reactions |
| **Gestão de Leito** | Active | Bed occupancy, turnover and availability board |
| **Escala de Enfermagem** | Active | Shift dimensioning by acuity; COFEN compliance |
| **NoMaster** | Active | Executive dashboard across all AURIA modules |

The flagship UX is the **RHPM risk queue**: every ICU patient ranked by deterioration risk in real time, with a recommended clinical action attached to each alert (antibiotic, blood culture, urgent medical evaluation).

Company is based in **Governador Valadares, MG**, founded by a healthcare operator with 15+ years on the hospital floor. The product positioning is *"tech born inside the hospital, not by engineers far from the ICU."*

---

## Sources

- **Live site (current):** [argosystems.com.br](https://argosystems.com.br)
- **GitHub:** [diogoalvesdossantos100-cell/argosystems](https://github.com/diogoalvesdossantos100-cell/argosystems) — single `index.html` powering the current marketing site (the one we are replacing).
- **Related repos (private / partial):** `auria-platform`, `nosepsis-demo`, `rhpm-risk-engine`, `AUIA-HPM`, `noreacao` — listed on the same GitHub org. Browse the org to dig deeper.

> **Reader:** the GitHub repos above contain real product copy, the current dashboard mockup, and module names exactly as the founder ships them. Always read them before inventing words or colors.

---

## How to use this system

Drop the design tokens in `colors_and_type.css` into any page and you'll get a cohesive Argo / AURIA aesthetic for free. For higher-fidelity work, the UI kits under `ui_kits/` contain pixel-accurate JSX components you can import.

```html
<link rel="stylesheet" href="colors_and_type.css" />
```

```jsx
import { CommandHero } from './ui_kits/marketing/Hero.jsx';
import { RiskQueue } from './ui_kits/dashboard/RiskQueue.jsx';
```

---

## Index

```
README.md                  ← you are here
SKILL.md                   ← agent-invocable skill manifest
colors_and_type.css        ← design tokens (colors, type, motion, radii)
assets/
  argo-wordmark.svg          ← primary lockup
  argo-mark.svg              ← compact mark / favicon-grade
  auria-wordmark.svg         ← AURIA platform mark
  module-glyphs/             ← one SVG glyph per AURIA module
  textures/                  ← grid, noise, atmospheric overlays
fonts/                     ← Syne, Geist (display, sans, mono)
preview/                   ← Design System tab cards
ui_kits/
  marketing/                 ← Marketing site recreation (hero, nav, sections, footer)
    index.html
    Nav.jsx, Hero.jsx, OperationalNumbers.jsx, ModuleGrid.jsx,
    Steps.jsx, ContactForm.jsx, Footer.jsx, Backdrop.jsx
  dashboard/                 ← NoSepsis command center
    index.html
    Sidebar.jsx, TopBar.jsx, RiskQueue.jsx, PatientDetail.jsx,
    HeatMap.jsx, ActivityStream.jsx, ScoreCard.jsx, Sparkline.jsx
```

---

## CONTENT FUNDAMENTALS

The voice is **Portuguese (Brazil)** — institutional, clinical, sober. Never cute. Never tech-bro.

**Tone**
- Authoritative and quiet. Reads like a senior intensivist briefing a board.
- Says exactly what the system does in clinical language: *"identifica pacientes em risco de sepse com horas de antecedência."*
- Never hyperbole. *"Pode salvar vidas"* is fine because it's literally the use case; *"revoluciona a UTI"* is not.

**Person & address**
- Third person about the product (*"O NoSepsis monitora..."*, *"A plataforma AURIA..."*).
- Second person plural / formal "você" for CTAs (*"Solicitar piloto"*, *"Ver como funciona"*).
- First person plural ("nós", "nossa equipe") only in the *Quem somos* section and footer.

**Casing**
- **Headlines:** sentence case. *"Sepse identificada antes que seja tarde demais."*
- **Eyebrows / tags:** ALL CAPS, 2–3 px letter-spacing, small (10–12 px). *"INTELIGÊNCIA CLÍNICA — UTI"*.
- **Buttons:** sentence case, no period. *"Solicitar piloto →"*.
- **Module names:** TitleCase with no space — *"NoSepsis"*, *"NoPAV"*, *"NoReação"*. Never *"No Sepsis"*.
- **Numbers in metrics:** keep the symbol attached — *"R$18k"*, *"6h"*, *"91%"*. Never *"6 h"* or *"R$ 18 mil"*.

**Vibe**
- Operational. Reads like a control room: timestamps, scores, bed numbers, monitored hours.
- Honest about scope. *"Implantação em 30 dias"*, *"piloto com resultado mensurável no primeiro mês"* — concrete.
- Brazilian institutional credentials when they help (CNPJ, LGPD, CFM, COFEN) — never decorative.

**Emoji**
- **None** in marketing copy or UI. The current site uses emoji in module cards (🏥 🎓 ⚖️ 📍 🫁 🧠 🩸 🛏️ 👩‍⚕️ 📊) — **we are removing these.** Replace with custom monoline glyphs from `assets/module-glyphs/`.

**Example copy that hits the mark**
- *"Sepse identificada antes que seja tarde demais."* — hero
- *"Tecnologia nascida dentro do hospital."* — about
- *"Não é só um número de risco — o sistema sugere a ação."* — feature
- *"Centro de comando hospitalar em tempo real."* — what the dashboard should evoke

---

## VISUAL FOUNDATIONS

The redesign brief: glassmorphism, ambient glow, layered backgrounds, atmospheric gradients, subtle particles, cinematic blur, premium motion. We deliver on this with restraint — no neon, no rainbow gradients, no AI-slop.

### Palette

Built on near-black with a single chromatic identity: **Argo Violet → Signal Cyan**. Operational colors (critical / warning / stable) borrowed from the medical signal universe.

| Token | Hex | Use |
|---|---|---|
| `--ink-0` | `#05060B` | Deepest page background |
| `--ink-1` | `#0A0B14` | Body background |
| `--ink-2` | `#0F1120` | Cards, panels |
| `--ink-3` | `#16182A` | Elevated surfaces / popovers |
| `--line-1` | `rgba(255,255,255,0.06)` | Hairline divider |
| `--line-2` | `rgba(255,255,255,0.10)` | Hovered border |
| `--violet-500` | `#7C5CFF` | Argo primary |
| `--violet-300` | `#A892FF` | Hover / light accents |
| `--cyan-400` | `#66E0FF` | Signal cyan (data, links) |
| `--cyan-200` | `#B6F0FF` | Soft cyan glow |
| `--critical` | `#FF5A6A` | Alto risco |
| `--warning` | `#F5B454` | Risco médio |
| `--stable` | `#3DDC97` | Controle / verde clínico |
| `--text-1` | `#F2F3F8` | Primary text |
| `--text-2` | `rgba(242,243,248,0.62)` | Secondary text |
| `--text-3` | `rgba(242,243,248,0.38)` | Tertiary / labels |

Gradients are used sparingly and only on **type** or **glow halos** — never on container fills.

- `--grad-aurora`: `linear-gradient(135deg, #7C5CFF 0%, #66E0FF 100%)` — display type accent, primary CTA glow.
- `--grad-deepfield`: `radial-gradient(60% 60% at 50% 0%, rgba(124,92,255,0.18), transparent 70%)` — atmospheric hero glow.
- `--grad-signal`: `linear-gradient(180deg, rgba(102,224,255,0.10), transparent)` — soft cyan wash for telemetry sections.

### Type

- **Display:** **Syne** 800 — kept from the current brand. Tight tracking (`-0.02em`), sentence case. Used for h1/h2/numeric metrics.
- **Sans:** **Geist Sans** (Vercel) 400/500/600 — replaces DM Sans. Sharper, more institutional, better numerals. *(Substitution flagged below.)*
- **Mono:** **Geist Mono** 400/500 — used for telemetry: scores, bed numbers, timestamps, vital signs. Tabular figures on.

> **⚠ Font substitution flagged:** the current site loads Syne + DM Sans from Google Fonts. We are *keeping* Syne and *switching DM Sans → Geist*. Geist is open-source under SIL OFL. If the user prefers to keep DM Sans, swap `--font-sans` in `colors_and_type.css`.

### Spacing

Base unit: **4 px**. Scale: 4, 8, 12, 16, 20, 24, 32, 40, 56, 72, 96, 128. Marketing sections use 96/128px vertical rhythm. Dashboard panels use 12/16/20 internal padding.

### Radii

| Token | px | Use |
|---|---|---|
| `--r-1` | 6 | Inline pills, badges |
| `--r-2` | 10 | Inputs, buttons |
| `--r-3` | 14 | Cards, panels |
| `--r-4` | 20 | Hero glass slabs |
| `--r-full` | 9999 | Capsule, dot |

### Borders

- **Hairline.** Every surface gets a 1px border at `rgba(255,255,255,0.06)`. No exceptions.
- On hover, lift to `rgba(255,255,255,0.10)` and *additionally* show a `0 0 0 1px var(--violet-500/30)` inner ring for interactive cards.
- Sharp 90° corners are reserved for "operational" panels (live tiles in the dashboard). Marketing surfaces use `--r-3` or `--r-4`.

### Shadows

Layered, **never** soft default Material.

- `--shadow-glass`: `0 1px 0 rgba(255,255,255,0.04) inset, 0 30px 80px -20px rgba(0,0,0,0.6)` — premium card.
- `--shadow-lift`: `0 20px 50px -20px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.04)` — floating panels.
- `--shadow-glow-violet`: `0 0 40px -10px rgba(124,92,255,0.5)` — CTA, active state.
- `--shadow-glow-cyan`: `0 0 60px -20px rgba(102,224,255,0.4)` — data highlights.

### Backgrounds

The page is layered, **not** a flat black:

1. Base `--ink-0`.
2. A faint **grid texture** (`assets/textures/grid.svg`, 32px, 6% opacity) anchors operational sections.
3. Two or three large **orbs** — `filter: blur(120px)`, 18%/12%/8% opacity, slowly drifting (60s+ loop).
4. A canvas of **subtle particles** (≤150 dots, 0.3–1.5px) drifting at 0.1–0.3 px/frame.
5. A horizon **deepfield gradient** at the top of major sections for cinematic falloff.

No stock photos. No 3D hero renders. The hero IS the dashboard.

### Glassmorphism

Real glass, not the AI-slop kind:

- `background: rgba(15,17,32,0.55);`
- `backdrop-filter: blur(20px) saturate(140%);`
- `border: 1px solid rgba(255,255,255,0.07);`
- Top-edge highlight: `box-shadow: 0 1px 0 rgba(255,255,255,0.06) inset;`

Used for: nav bar, floating dashboard panels, popovers, the contact form card. Never for full-page chrome.

### Motion

Easing tokens:

- `--ease-out-soft`: `cubic-bezier(0.2, 0.8, 0.2, 1)` — primary UI transitions.
- `--ease-spring`: `cubic-bezier(0.34, 1.56, 0.64, 1)` — entrance bounces (subtle).
- `--ease-linear-tape`: `linear` — drifting orbs, marquees, real-time tickers.

Durations: 150ms (hover), 300ms (state), 600ms (reveal), 1200–2000ms (ambient).

- **Reveal on scroll:** 30px translateY + opacity over 700ms. Staggered 100ms.
- **Pulse:** `opacity 1 → 0.3 → 1` over 2s for live dots.
- **Number tick:** count up over 1.2s with `ease-out-soft` on numeric metrics that enter the viewport.
- **No bounce** on serious data. **No spring** on alerts. Reserve playful motion for marketing.

### Hover / Press states

- **Buttons (primary):** brighten 6% + `translateY(-1px)` + add `--shadow-glow-violet` on hover. On press: drop back to 0, dim 4%.
- **Cards:** border lifts to `--line-2`, inner violet ring fades in at 30% opacity, `translateY(-2px)`.
- **Nav links:** color `--text-2 → --text-1`, no underline. A 1px violet line slides in under the link from left to right (200ms).
- **Inputs (focus):** border `rgba(124,92,255,0.4)`, soft glow `0 0 0 4px rgba(124,92,255,0.10)`.

### Transparency & Blur

Used **only** for layered chrome (nav, floating panels, popovers, the contact form's halo). Body content and dashboard tiles are **opaque** — readability above style.

### Imagery

Cool palette. Cinematic. If product imagery is ever needed:
- Hospital interiors at night, blue-tinted monitor light.
- Slight film grain (1–2%).
- Never warm tones. Never stock-photo doctors-pointing-at-laptops.

### Corners (radii) recap

Big surfaces curve more (`--r-4` for hero glass slabs), data tiles less (`--r-3`), pills and badges minimal (`--r-1` to capsule). Avoid mixing `--r-2` and `--r-3` inside the same panel; pick one tier and stay.

### Cards

A canonical AURIA card:

```
background: var(--ink-2);
border: 1px solid var(--line-1);
border-radius: var(--r-3);
box-shadow: var(--shadow-glass);
padding: 20–28px depending on density.
```

On hover, the card lifts 2px, the border switches to `--line-2`, and an inner violet ring fades in. No box-shadow expansion — the shadow stays put. (We are deliberately NOT doing the rounded-corner-with-colored-left-border pattern; it reads bootstrap.)

---

## ICONOGRAPHY

The current site uses emoji (🏥 🎓 ⚖️ 📍 🫁 🧠 🩸 🛏️ 👩‍⚕️ 📊) as module icons. **We are replacing all emoji with proper iconography.**

**Approach**
- **Lucide icons** ([lucide.dev](https://lucide.dev)) via CDN as the workhorse system — 1.5px stroke, 24px grid, monoline. Matches Linear / Vercel / Raycast.
- **Custom AURIA module glyphs** in `assets/module-glyphs/` for each of the seven modules (NoSepsis, NoPAV, NoDelirium, NoReação, Gestão de Leito, Escala de Enfermagem, NoMaster). Monoline, 24×24, single-stroke at 1.5px. These are part of the brand identity and should never be replaced with stock icons.
- **No emoji anywhere.** Not even in tooltips.
- **No unicode symbols as icons.** Acceptable unicode: arrows (← → ↑ ↓), bullets (·), em-dash (—). Anything else gets an SVG.

**Logos** *(see Identity v2 above for the full sheet)*
- `assets/argo-wordmark.svg` — primary horizontal lockup (mark + ARGO + SYSTEMS caption).
- `assets/argo-mark.svg` — stencil A symbol only.
- `assets/argo-monogram.svg` — boxed mark for app icons and avatars.
- `assets/auria-wordmark.svg` — AURIA platform wordmark (sub-brand, used inside content).
- `assets/auria-platform-label.svg` — compact "AURIA · PLATFORM" label tag.

> **⚠ Icon set substitution flagged:** the source repo has no icon assets — only emoji. The Lucide + custom-glyph approach is a substitution. If the user wants a different set (Phosphor, Heroicons, custom), point us at it.

---

See `SKILL.md` for agent invocation instructions.
