/* global React */
// dashboard/TopBar.jsx

const TopBar = () => {
  const [time, setTime] = React.useState('14:38:46');
  React.useEffect(() => {
    const tick = () => {
      const d = new Date();
      setTime(`${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}:${String(d.getSeconds()).padStart(2,'0')}`);
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);

  return (
    <header className="tb">
      <div className="tb-l">
        <div className="tb-crumbs">
          <span className="tb-crumb">AURIA</span>
          <span className="tb-crumb-sep">/</span>
          <span className="tb-crumb">NoSepsis</span>
          <span className="tb-crumb-sep">/</span>
          <span className="tb-crumb tb-crumb-on">UTI-2A</span>
        </div>
        <div className="tb-title-row">
          <h1 className="tb-title">Centro de comando</h1>
          <span className="pill pill-stable"><span className="dot" style={{background:'currentColor'}}/>AO VIVO</span>
        </div>
      </div>

      <div className="tb-r">
        <div className="tb-clock">
          <div className="tb-clock-date">14 mai 2026 · qui</div>
          <div className="tb-clock-time mono">{time} <span className="tb-tz">BRT</span></div>
        </div>
        <div className="tb-sep"/>
        <button className="tb-icon-btn" title="Filtros">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></svg>
        </button>
        <button className="tb-icon-btn" title="Notificações">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>
          <span className="tb-bell-dot"/>
        </button>
        <button className="btn btn-primary btn-sm">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          Novo paciente
        </button>
      </div>
    </header>
  );
};

window.TopBar = TopBar;
