/* global React */
// dashboard/Sidebar.jsx

const ModuleItem = ({ glyph, label, count, active, alerts }) => (
  <button className={`sb-item ${active ? 'sb-item-active' : ''}`}>
    <span className="sb-item-icon">{glyph}</span>
    <span className="sb-item-label">{label}</span>
    {alerts > 0 && <span className="sb-item-badge">{alerts}</span>}
    {count != null && <span className="sb-item-count">{count}</span>}
  </button>
);

const G = ({ d }) => (<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">{d}</svg>);
const g_nosepsis  = <G d={<><path d="M2 12 H6 L8 6 L11 18 L13 9 L15 14 L18 12 H22"/><circle cx="18" cy="12" r="2.2"/></>}/>;
const g_nopav     = <G d={<><path d="M12 4 V14"/><path d="M12 8 C8 8 5 10 5 14 C5 18 7 20 9 20 C11 20 12 19 12 16"/><path d="M12 8 C16 8 19 10 19 14 C19 18 17 20 15 20 C13 20 12 19 12 16"/></>}/>;
const g_brain     = <G d={<><path d="M3 12 H6 L7 9 L8 15 L9 11 L10 13"/><path d="M11 7 C13 5 17 5 19 8 C21 11 20 14 18 16 C19 18 18 20 16 20 C14 20 13 18 13 16"/></>}/>;
const g_drop      = <G d={<><path d="M9 3 H15 V6 L17 8 V18 C17 20 15 21 13 21 H11 C9 21 7 20 7 18 V8 L9 6 Z"/></>}/>;
const g_bed       = <G d={<><path d="M3 18 V10 H13 V14 H21 V18"/><path d="M3 20 H21"/><circle cx="7" cy="13" r="1.4"/></>}/>;
const g_team      = <G d={<><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10 H21"/><path d="M8 3 V7 M16 3 V7"/></>}/>;
const g_grid      = <G d={<><rect x="3" y="3" width="8" height="10" rx="1"/><rect x="13" y="3" width="8" height="6" rx="1"/><rect x="3" y="15" width="8" height="6" rx="1"/><rect x="13" y="11" width="8" height="10" rx="1"/></>}/>;
const g_home      = <G d={<><path d="M3 11 L12 3 L21 11"/><path d="M5 9 V21 H19 V9"/></>}/>;
const g_search    = <G d={<><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></>}/>;
const g_gear      = <G d={<><circle cx="12" cy="12" r="3"/><path d="M19.4 15 a1.65 1.65 0 0 0 .33 1.82 l.06 .06 a2 2 0 1 1 -2.83 2.83 l-.06 -.06 a1.65 1.65 0 0 0 -1.82 -.33 1.65 1.65 0 0 0 -1 1.51 V21 a2 2 0 0 1 -4 0 v-.09 A1.65 1.65 0 0 0 9 19.4 a1.65 1.65 0 0 0 -1.82 .33 l-.06 .06 a2 2 0 0 1 -2.83 -2.83 l.06 -.06 a1.65 1.65 0 0 0 .33 -1.82 1.65 1.65 0 0 0 -1.51 -1 H3 a2 2 0 0 1 0 -4 h.09 A1.65 1.65 0 0 0 4.6 9 a1.65 1.65 0 0 0 -.33 -1.82 l-.06 -.06 a2 2 0 0 1 2.83 -2.83 l.06 .06 a1.65 1.65 0 0 0 1.82 .33 H9 a1.65 1.65 0 0 0 1 -1.51 V3 a2 2 0 0 1 4 0 v.09 a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82 -.33 l.06 -.06 a2 2 0 0 1 2.83 2.83 l-.06 .06 a1.65 1.65 0 0 0 -.33 1.82 V9 a1.65 1.65 0 0 0 1.51 1 H21 a2 2 0 0 1 0 4 h-.09 a1.65 1.65 0 0 0 -1.51 1 z"/></>}/>;

const Sidebar = () => {
  return (
    <aside className="sb">
      <div className="sb-head">
        <div className="sb-brand">
          <svg viewBox="0 0 32 32" width="22" height="22"><path d="M8 24 L16 8 L24 24 M11 19 L21 19" stroke="#F2F3F8" strokeWidth="2.4" strokeLinecap="square" fill="none"/><rect x="6" y="27" width="20" height="2" fill="#66E0FF"/></svg>
          <div>
            <div className="sb-brand-name">ARGO</div>
            <div className="sb-brand-sub">AURIA · v3.2</div>
          </div>
        </div>
      </div>

      <div className="sb-tenant">
        <div className="sb-tenant-avatar">HS</div>
        <div className="sb-tenant-info">
          <div className="sb-tenant-name">Hospital São Lucas</div>
          <div className="sb-tenant-meta">UTI 2A · 22 leitos · ao vivo</div>
        </div>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><polyline points="6 9 12 15 18 9"/></svg>
      </div>

      <div className="sb-search">
        <span className="sb-search-icon">{g_search}</span>
        <input placeholder="Buscar paciente, leito…" />
        <kbd>⌘K</kbd>
      </div>

      <nav className="sb-nav">
        <div className="sb-section-h">PLATAFORMA</div>
        <ModuleItem glyph={g_home} label="Visão geral" active />
        <ModuleItem glyph={g_grid} label="NoMaster" />

        <div className="sb-section-h">MÓDULOS CLÍNICOS</div>
        <ModuleItem glyph={g_nosepsis} label="NoSepsis" alerts={3} count={20} />
        <ModuleItem glyph={g_nopav} label="NoPAV" count={12} />
        <ModuleItem glyph={g_brain} label="NoDelirium" alerts={1} count={18} />
        <ModuleItem glyph={g_drop} label="NoReação" />

        <div className="sb-section-h">OPERAÇÕES</div>
        <ModuleItem glyph={g_bed} label="Gestão de Leito" count={22} />
        <ModuleItem glyph={g_team} label="Escala Enfermagem" />
      </nav>

      <div className="sb-foot">
        <button className="sb-foot-btn">{g_gear}<span>Configurações</span></button>
        <div className="sb-user">
          <div className="sb-user-avatar">DJ</div>
          <div className="sb-user-info">
            <div className="sb-user-name">Dr. Diogo Justino</div>
            <div className="sb-user-meta">Intensivista · plantão</div>
          </div>
          <span className="live-dot"><i/></span>
        </div>
      </div>
    </aside>
  );
};

window.Sidebar = Sidebar;
