/* global React */
// dashboard/Panels.jsx — KPI tiles, charts, queue, activity feed
// All visual building blocks of the command center

// ----- Shared chart helpers -----
const SparkArea = ({ points, stroke = '#7C5CFF', width = '100%', height = 56 }) => {
  const max = Math.max(...points), min = Math.min(...points), range = max - min || 1;
  const w = 200, h = height - 8;
  const step = w / (points.length - 1);
  const path = points.map((p, i) => `${i * step},${h - ((p - min) / range) * (h - 4) - 2}`).join(' ');
  return (
    <svg viewBox={`0 0 ${w} ${height}`} preserveAspectRatio="none" style={{ width, height, display:'block' }}>
      <defs>
        <linearGradient id={`g-${stroke.replace('#','')}`} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor={stroke} stopOpacity="0.32"/>
          <stop offset="1" stopColor={stroke} stopOpacity="0"/>
        </linearGradient>
      </defs>
      <polyline points={`0,${height} ${path} ${w},${height}`} fill={`url(#g-${stroke.replace('#','')})`} stroke="none"/>
      <polyline points={path} stroke={stroke} strokeWidth="1.6" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
};

// ----- KPI band -----
const KPI = ({ label, value, suffix, delta, deltaPos, sparkPoints, color, dotColor }) => (
  <div className="kpi">
    <div className="kpi-label"><span className="ld" style={{background:dotColor, boxShadow:`0 0 6px ${dotColor}`}}/>{label}</div>
    <div className="kpi-row">
      <div className="kpi-val">{value}<span className="kpi-suf">{suffix}</span></div>
      <div className={`kpi-delta ${deltaPos ? 'pos' : 'neg'}`}>{deltaPos ? '▲' : '▼'} {delta}</div>
    </div>
    <SparkArea points={sparkPoints} stroke={color}/>
  </div>
);

const KPIBand = () => (
  <div className="kpi-band">
    <KPI label="SCORE OPERACIONAL" value="0.84" suffix="" delta="+0.06" deltaPos sparkPoints={[0.55,0.6,0.62,0.66,0.7,0.72,0.78,0.8,0.82,0.84]} color="#7C5CFF" dotColor="#7C5CFF"/>
    <KPI label="ALERTAS ATIVOS" value="7" suffix="" delta="+2 / 30min" deltaPos sparkPoints={[2,2,3,3,4,5,5,6,7,7]} color="#FF5A6A" dotColor="#FF5A6A"/>
    <KPI label="LEITOS MONITORADOS" value="20" suffix="/22" delta="91% ocup." deltaPos sparkPoints={[18,18,19,19,20,20,20,20,20,20]} color="#3DDC97" dotColor="#3DDC97"/>
    <KPI label="ANTECEDÊNCIA MÉDIA" value="6.4" suffix="h" delta="+0.3h vs onte" deltaPos sparkPoints={[5.4,5.6,5.8,6,6.1,6.2,6.2,6.3,6.4,6.4]} color="#66E0FF" dotColor="#66E0FF"/>
  </div>
);

// ----- Risk queue -----
const PATIENTS = [
  { leito:'04', code:'J.M.S.', age:67, sex:'M', diag:'Pneumonia → suspeita sepse', level:'alto', score:0.91, hours:6, action:'ATB sugerido', spark:[0.2,0.3,0.35,0.5,0.6,0.7,0.82,0.91] },
  { leito:'11', code:'M.A.R.', age:54, sex:'F', diag:'Pós-op abdominal', level:'alto', score:0.84, hours:2, action:'Hemocultura', spark:[0.3,0.35,0.45,0.5,0.6,0.7,0.75,0.84] },
  { leito:'19', code:'P.O.S.', age:78, sex:'M', diag:'ITU complicada', level:'alto', score:0.78, hours:9, action:'Reavaliar 1h', spark:[0.4,0.5,0.55,0.62,0.65,0.7,0.74,0.78] },
  { leito:'07', code:'C.F.L.', age:42, sex:'F', diag:'Politrauma', level:'medio', score:0.63, hours:14, action:'Lactato', spark:[0.4,0.45,0.5,0.55,0.58,0.6,0.62,0.63] },
  { leito:'15', code:'A.P.B.', age:69, sex:'M', diag:'IRA', level:'medio', score:0.58, hours:1, action:'Coleta gaso', spark:[0.2,0.25,0.3,0.35,0.45,0.5,0.55,0.58] },
  { leito:'13', code:'L.O.M.', age:50, sex:'F', diag:'Pancreatite', level:'medio', score:0.51, hours:22, action:'Manter ATB', spark:[0.5,0.52,0.5,0.48,0.49,0.5,0.51,0.51] },
  { leito:'02', code:'R.T.M.', age:71, sex:'M', diag:'AVCi pós', level:'baixo', score:0.21, hours:48, action:'Estável', spark:[0.3,0.28,0.25,0.24,0.22,0.21,0.21,0.21] },
  { leito:'08', code:'S.V.D.', age:60, sex:'F', diag:'IAM pós-revasc', level:'baixo', score:0.18, hours:36, action:'Estável', spark:[0.22,0.2,0.19,0.18,0.18,0.18,0.18,0.18] },
];

const RiskQueue = ({ onSelect, selected }) => {
  const [filter, setFilter] = React.useState('all');
  const filtered = filter === 'all' ? PATIENTS : PATIENTS.filter(p => p.level === filter);
  return (
    <div className="panel queue-panel">
      <div className="panel-head">
        <div className="panel-title">FILA DE RISCO · RHPM</div>
        <div className="panel-actions">
          <div className="seg-mini">
            <button onClick={() => setFilter('all')} className={filter==='all'?'on':''}>Todos · {PATIENTS.length}</button>
            <button onClick={() => setFilter('alto')} className={filter==='alto'?'on':''}>Alto · 3</button>
            <button onClick={() => setFilter('medio')} className={filter==='medio'?'on':''}>Médio · 3</button>
            <button onClick={() => setFilter('baixo')} className={filter==='baixo'?'on':''}>Ctrl · 2</button>
          </div>
          <span className="live-dot"><i/></span>
        </div>
      </div>
      <div className="queue-list">
        <div className="queue-row queue-head-row">
          <div>LEITO</div><div>PACIENTE</div><div>DIAGNÓSTICO</div><div>TENDÊNCIA</div><div>SCORE</div><div>AÇÃO</div><div></div>
        </div>
        {filtered.map(p => {
          const c = p.level === 'alto' ? '#FF5A6A' : p.level === 'medio' ? '#F5B454' : '#3DDC97';
          const cls = p.level === 'alto' ? 'critical' : p.level === 'medio' ? 'warning' : 'stable';
          const lbl = p.level === 'alto' ? 'ALTO' : p.level === 'medio' ? 'MÉDIO' : 'CTRL';
          const isSel = selected === p.leito;
          return (
            <div key={p.leito} className={`queue-row pr-${cls} ${isSel?'pr-selected':''}`} onClick={() => onSelect && onSelect(p)}>
              <div className="q-leito mono">LT {p.leito}</div>
              <div>
                <div className="q-name">{p.code}</div>
                <div className="q-sub mono">{p.age}{p.sex} · {p.hours}h monitorado</div>
              </div>
              <div className="q-diag">{p.diag}</div>
              <div className="q-spark"><SparkArea points={p.spark} stroke={c} height={28}/></div>
              <div className="q-score mono" style={{color:c}}>{p.score.toFixed(2)}</div>
              <div><span className={`pill pill-${cls}`}>{lbl}</span><div className="q-action">{p.action}</div></div>
              <div className="q-arrow">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><polyline points="9 18 15 12 9 6"/></svg>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// ----- Patient detail panel -----
const VitalChart = ({ label, value, unit, color, points, range }) => {
  const max = Math.max(...points, range[1]);
  const min = Math.min(...points, range[0]);
  const r = max - min || 1;
  return (
    <div className="vit">
      <div className="vit-head">
        <div className="vit-label">{label}</div>
        <div className="vit-val mono" style={{color}}>{value}<span className="vit-unit">{unit}</span></div>
      </div>
      <svg viewBox="0 0 200 36" preserveAspectRatio="none" className="vit-svg">
        <line x1="0" y1={36 - ((range[1]-min)/r)*32 - 2} x2="200" y2={36 - ((range[1]-min)/r)*32 - 2} stroke="rgba(255,255,255,0.04)" strokeDasharray="2 4"/>
        <line x1="0" y1={36 - ((range[0]-min)/r)*32 - 2} x2="200" y2={36 - ((range[0]-min)/r)*32 - 2} stroke="rgba(255,255,255,0.04)" strokeDasharray="2 4"/>
        <polyline points={points.map((p,i) => `${(i/(points.length-1))*200},${36 - ((p-min)/r)*32 - 2}`).join(' ')} stroke={color} strokeWidth="1.4" fill="none"/>
      </svg>
    </div>
  );
};

const PatientDetail = ({ patient }) => {
  const p = patient || PATIENTS[0];
  const c = p.level === 'alto' ? '#FF5A6A' : p.level === 'medio' ? '#F5B454' : '#3DDC97';
  return (
    <div className="panel pd">
      <div className="panel-head">
        <div className="pd-title">
          <div className="pd-leito mono">LT {p.leito}</div>
          <div>
            <div className="pd-name">{p.code}</div>
            <div className="pd-sub mono">{p.age}{p.sex} · {p.diag}</div>
          </div>
        </div>
        <div className="pd-score-block">
          <RiskGaugeBig value={p.score} color={c}/>
          <div className="pd-trend">
            <div className="mono" style={{color:c, fontSize:11}}>▲ 0.06 / 1h</div>
            <div className="mono" style={{color:'var(--text-3)', fontSize:10}}>antecedência: 6h</div>
          </div>
        </div>
      </div>

      <div className="pd-vitals">
        <VitalChart label="FC" value="124" unit="bpm" color="#FF8E99" range={[90,140]} points={[100,105,110,108,115,118,120,124]}/>
        <VitalChart label="PAS" value="88" unit="mmHg" color="#F5B454" range={[80,140]} points={[120,115,108,100,95,92,90,88]}/>
        <VitalChart label="SpO₂" value="92" unit="%" color="#66E0FF" range={[90,100]} points={[97,96,95,95,94,93,92,92]}/>
        <VitalChart label="Lactato" value="3.8" unit="mmol/L" color="#FF5A6A" range={[1,5]} points={[1.8,2.1,2.4,2.8,3.0,3.3,3.6,3.8]}/>
      </div>

      <div className="pd-action">
        <div className="pd-action-head">
          <span className="ld ld-crit"/>
          <span className="pd-action-title">Ação clínica sugerida</span>
          <span className="mono" style={{fontSize:10, color:'var(--text-3)'}}>RHPM · confiança 91%</span>
        </div>
        <div className="pd-action-body">
          <strong>Iniciar antibioticoterapia empírica</strong> (piperacilina-tazobactam 4.5g IV 8/8h) e <strong>coleta de 2 hemoculturas</strong>. Reavaliar lactato em 2h.
        </div>
        <div className="pd-action-foot">
          <button className="btn btn-primary btn-sm">Aceitar e acionar plantão</button>
          <button className="btn btn-ghost btn-sm">Editar</button>
          <button className="btn btn-ghost btn-sm">Descartar</button>
        </div>
      </div>
    </div>
  );
};

const RiskGaugeBig = ({ value, color }) => {
  const C = 2 * Math.PI * 30;
  const dash = C * value;
  return (
    <svg width="84" height="84" viewBox="0 0 84 84">
      <circle cx="42" cy="42" r="30" stroke="rgba(255,255,255,0.06)" strokeWidth="6" fill="none"/>
      <circle cx="42" cy="42" r="30" stroke={color} strokeWidth="6" fill="none"
        strokeDasharray={`${dash} ${C}`} strokeLinecap="round" transform="rotate(-90 42 42)"
        style={{ filter: `drop-shadow(0 0 6px ${color})` }}/>
      <text x="42" y="46" textAnchor="middle" fontFamily="Geist Mono, monospace" fontSize="18" fontWeight="600" fill="#F2F3F8">{value.toFixed(2)}</text>
    </svg>
  );
};

window.KPIBand = KPIBand;
window.RiskQueue = RiskQueue;
window.PatientDetail = PatientDetail;
window.PATIENTS_DATA = PATIENTS;
