/* global React */
// dashboard/RightRail.jsx — Heatmap + Activity + Score breakdown

const HeatMap = () => {
  const cells = React.useMemo(() =>
    Array.from({ length: 22 * 14 }, (_, i) => {
      const leito = Math.floor(i / 14);
      const t = i % 14;
      const base = (leito === 4 || leito === 11 || leito === 19) ? 0.65 :
                   (leito === 7 || leito === 15 || leito === 13) ? 0.42 : 0.18;
      const wave = (Math.sin(leito * 1.1 + t * 0.5) + 1) / 2 * 0.3;
      return Math.min(0.98, base + wave * Math.random());
    }), []);
  const color = (v) => {
    if (v < 0.3) return `rgba(61,220,151,${0.15 + v * 0.6})`;
    if (v < 0.6) return `rgba(245,180,84,${0.2 + v * 0.6})`;
    return `rgba(255,90,106,${0.3 + v * 0.55})`;
  };
  return (
    <div className="panel">
      <div className="panel-head">
        <div className="panel-title">HEATMAP · LEITO × HORA</div>
        <div className="hm-legend">
          <span><i style={{background:'#3DDC97'}}/>baixo</span>
          <span><i style={{background:'#F5B454'}}/>médio</span>
          <span><i style={{background:'#FF5A6A'}}/>alto</span>
        </div>
      </div>
      <div className="hm-grid hm-grid-big">
        <div className="hm-row hm-row-head">
          <div className="hm-leito"></div>
          {Array.from({length:14}).map((_,i) => <div key={i} className="hm-thead mono">{14-i}h</div>)}
        </div>
        {Array.from({ length: 22 }).map((_, leito) => (
          <div className="hm-row" key={leito}>
            <div className="hm-leito mono">{String(leito + 1).padStart(2, '0')}</div>
            {Array.from({ length: 14 }).map((__, t) => {
              const v = cells[leito * 14 + t];
              return <div key={t} className="hm-cell" style={{ background: color(v) }} title={`Leito ${leito+1} · ${14-t}h atrás · ${v.toFixed(2)}`}/>;
            })}
          </div>
        ))}
      </div>
    </div>
  );
};

const ActivityFeed = () => {
  const items = [
    { t: '14:38:21', dot: '#FF5A6A', text: 'NoSepsis · score 0.91 → Leito 04', tag: 'ATB sugerido', tagCls:'pill-critical' },
    { t: '14:36:02', dot: '#F5B454', text: 'NoDelirium · CAM-ICU positivo · Leito 09', tag: 'avaliação', tagCls:'pill-warning' },
    { t: '14:34:47', dot: '#FF5A6A', text: 'NoSepsis · score 0.84 → Leito 11', tag: 'hemocultura', tagCls:'pill-critical' },
    { t: '14:33:58', dot: '#66E0FF', text: 'NoPAV · bundle 5/5 mantido · Leito 13', tag: 'compliance', tagCls:'pill-cyan' },
    { t: '14:30:11', dot: '#A892FF', text: 'NoReação · transfusão iniciada · Leito 02', tag: 'monitorando', tagCls:'pill-violet' },
    { t: '14:27:44', dot: '#3DDC97', text: 'Leito 02 estabilizado · score 0.21', tag: 'controle', tagCls:'pill-stable' },
    { t: '14:24:32', dot: '#F5B454', text: 'NoDelirium · RASS +2 · Leito 07', tag: 'avaliação', tagCls:'pill-warning' },
    { t: '14:21:18', dot: '#66E0FF', text: 'Escala atualizada · turno 14h–19h', tag: '12 profis.', tagCls:'pill-cyan' },
  ];
  return (
    <div className="panel feed-panel">
      <div className="panel-head">
        <div className="panel-title">ACTIVITY STREAM</div>
        <span className="live-dot"><i/></span>
      </div>
      <div className="feed">
        {items.map((it, i) => (
          <div className="feed-row" key={i} style={{animationDelay:`${i*70}ms`}}>
            <span className="feed-bullet" style={{background:it.dot, boxShadow:`0 0 8px ${it.dot}`}}/>
            <div className="feed-body">
              <div className="feed-text">{it.text}</div>
              <div className="feed-meta">
                <span className="mono feed-time">{it.t}</span>
                <span className={`pill ${it.tagCls}`}>{it.tag}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const ScoreBreakdown = () => {
  const factors = [
    { name: 'Lactato', value: 0.85, weight: 'alto', color:'#FF5A6A' },
    { name: 'FC', value: 0.72, weight: 'alto', color:'#FF5A6A' },
    { name: 'PAS', value: 0.68, weight: 'médio', color:'#F5B454' },
    { name: 'Temperatura', value: 0.55, weight: 'médio', color:'#F5B454' },
    { name: 'Leucócitos', value: 0.42, weight: 'médio', color:'#F5B454' },
    { name: 'SpO₂', value: 0.28, weight: 'baixo', color:'#3DDC97' },
  ];
  return (
    <div className="panel">
      <div className="panel-head">
        <div className="panel-title">SCORE · FATORES · LEITO 04</div>
        <span className="pill pill-violet">RHPM v3.2</span>
      </div>
      <div className="sb-factors">
        {factors.map((f,i) => (
          <div className="sf" key={i}>
            <div className="sf-name">{f.name}</div>
            <div className="sf-bar"><div className="sf-fill" style={{width:`${f.value*100}%`, background:f.color, boxShadow:`0 0 12px ${f.color}66`}}/></div>
            <div className="sf-val mono">{f.value.toFixed(2)}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

window.HeatMap = HeatMap;
window.ActivityFeed = ActivityFeed;
window.ScoreBreakdown = ScoreBreakdown;
