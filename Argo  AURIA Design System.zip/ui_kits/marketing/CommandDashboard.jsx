/* global React */
// CommandDashboard.jsx — the giant "centro de comando" hero dashboard
// Live patient risk queue + floating overlay panels + heatmap + activity stream

const useTick = (ms = 1000) => {
  const [, setT] = React.useState(0);
  React.useEffect(() => {
    const id = setInterval(() => setT(t => t + 1), ms);
    return () => clearInterval(id);
  }, [ms]);
};

const Sparkline = ({ points, stroke = '#7C5CFF', fill = false, width = 80, height = 22 }) => {
  const max = Math.max(...points);
  const min = Math.min(...points);
  const range = max - min || 1;
  const step = width / (points.length - 1);
  const path = points.map((p, i) => `${i * step},${height - ((p - min) / range) * (height - 2) - 1}`).join(' ');
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} fill="none">
      {fill && (
        <polyline points={`0,${height} ${path} ${width},${height}`} fill={stroke} opacity="0.18" />
      )}
      <polyline points={path} stroke={stroke} strokeWidth="1.4" fill="none" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
};

const RiskGauge = ({ value = 0.91, color = '#FF5A6A' }) => {
  const C = 2 * Math.PI * 28;
  const dash = C * value;
  return (
    <svg width="76" height="76" viewBox="0 0 76 76">
      <circle cx="38" cy="38" r="28" stroke="rgba(255,255,255,0.06)" strokeWidth="6" fill="none" />
      <circle cx="38" cy="38" r="28" stroke={color} strokeWidth="6" fill="none"
        strokeDasharray={`${dash} ${C}`} strokeLinecap="round"
        transform="rotate(-90 38 38)"
        style={{ filter: `drop-shadow(0 0 6px ${color})`, transition: 'stroke-dasharray 800ms cubic-bezier(0.2,0.8,0.2,1)' }} />
      <text x="38" y="42" textAnchor="middle" fontFamily="Geist Mono, monospace" fontSize="16" fontWeight="600" fill="#F2F3F8">{value.toFixed(2)}</text>
    </svg>
  );
};

const Heatmap = () => {
  // 22 leitos × 12 columnas (last 12h). value 0..1
  const cells = React.useMemo(() => {
    return Array.from({ length: 22 * 12 }, (_, i) => {
      const leito = Math.floor(i / 12);
      const t = i % 12;
      // bias certain beds higher
      const base = (leito === 4 || leito === 11) ? 0.6 : (leito === 7 || leito === 15) ? 0.4 : 0.15;
      const noise = (Math.sin(leito * 1.3 + t * 0.6) + 1) / 2 * 0.35;
      return Math.min(0.98, base + noise * Math.random());
    });
  }, []);
  const color = (v) => {
    if (v < 0.3) return `rgba(61,220,151,${0.15 + v * 0.5})`;
    if (v < 0.6) return `rgba(245,180,84,${0.2 + v * 0.5})`;
    return `rgba(255,90,106,${0.3 + v * 0.5})`;
  };
  return (
    <div className="hm">
      <div className="hm-head">
        <div className="hm-label">HEATMAP — risco por leito × hora</div>
        <div className="hm-legend">
          <span><i style={{background:'#3DDC97'}}/>baixo</span>
          <span><i style={{background:'#F5B454'}}/>médio</span>
          <span><i style={{background:'#FF5A6A'}}/>alto</span>
        </div>
      </div>
      <div className="hm-grid">
        {Array.from({ length: 22 }).map((_, leito) => (
          <div className="hm-row" key={leito}>
            <div className="hm-leito">{String(leito + 1).padStart(2, '0')}</div>
            {Array.from({ length: 12 }).map((__, t) => {
              const v = cells[leito * 12 + t];
              return <div key={t} className="hm-cell" style={{ background: color(v) }} />;
            })}
          </div>
        ))}
      </div>
    </div>
  );
};

const ActivityStream = () => {
  const items = [
    { t: '14:38:21', dot: '#FF5A6A', text: 'NoSepsis · score 0.91 — Leito 04', tag: 'ATB sugerido' },
    { t: '14:36:02', dot: '#F5B454', text: 'NoDelirium · CAM-ICU positivo — Leito 09', tag: 'avaliação' },
    { t: '14:33:58', dot: '#66E0FF', text: 'NoPAV · bundle 5/5 — Leito 13', tag: 'compliance' },
    { t: '14:30:11', dot: '#FF5A6A', text: 'NoSepsis · score 0.84 — Leito 11', tag: 'hemocultura' },
    { t: '14:27:44', dot: '#3DDC97', text: 'Leito 02 estabilizado · score 0.21', tag: 'ok' },
  ];
  return (
    <div className="as">
      <div className="as-head">
        <div className="as-label">ACTIVITY STREAM · UTI</div>
        <span className="live-dot"><i/></span>
      </div>
      <div className="as-list">
        {items.map((it, i) => (
          <div className="as-row" key={i} style={{ animationDelay: `${i * 100}ms` }}>
            <span className="as-time mono">{it.t}</span>
            <span className="as-bullet" style={{ background: it.dot, boxShadow: `0 0 8px ${it.dot}` }} />
            <span className="as-text">{it.text}</span>
            <span className="as-tag">{it.tag}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

const PatientRow = ({ leito, code, level, score, hours, action, sparkPoints }) => {
  const colors = {
    alto: { stroke: '#FF5A6A', label: 'ALTO', cls: 'critical' },
    medio: { stroke: '#F5B454', label: 'MÉDIO', cls: 'warning' },
    baixo: { stroke: '#3DDC97', label: 'CTRL', cls: 'stable' },
  };
  const c = colors[level];
  return (
    <div className={`pr pr-${c.cls}`}>
      <div className="pr-leito mono">LT {leito}</div>
      <div className="pr-id">
        <div className="pr-name">{code}</div>
        <div className="pr-meta mono">{hours}h · {action}</div>
      </div>
      <div className="pr-spark"><Sparkline points={sparkPoints} stroke={c.stroke} fill /></div>
      <div className="pr-score mono" style={{color:c.stroke}}>{score.toFixed(2)}</div>
      <span className={`pill pill-${c.cls}`}>{c.label}</span>
    </div>
  );
};

const CommandDashboard = () => {
  // animated counter for score
  const [tick, setTick] = React.useState(0);
  React.useEffect(() => {
    const id = setInterval(() => setTick(t => t + 1), 2400);
    return () => clearInterval(id);
  }, []);

  // tiny oscillation for the floating gauge value
  const score = 0.89 + Math.sin(tick) * 0.02 + 0.02;

  return (
    <div className="cmd">
      {/* Top frame chrome */}
      <div className="cmd-chrome">
        <div className="cmd-dots">
          <span className="cmd-dot dot-r"/><span className="cmd-dot dot-y"/><span className="cmd-dot dot-g"/>
        </div>
        <div className="cmd-title mono">auria · nosepsis · uti-2a · ao vivo</div>
        <div className="cmd-clock mono">14:38:46 BRT</div>
      </div>

      {/* Main grid: left column (top tiles + queue) | right column (heatmap + activity) */}
      <div className="cmd-body">
        <div className="cmd-col-l">
          {/* metric tiles */}
          <div className="cmd-tiles">
            <div className="cmd-tile">
              <div className="cmd-tile-label">SCORE OPERACIONAL</div>
              <div className="cmd-tile-val">0.84<span className="cmd-tile-delta">▲ 0.06</span></div>
              <Sparkline points={[0.6,0.62,0.66,0.7,0.72,0.78,0.8,0.84]} stroke="#7C5CFF" fill width={150} height={24} />
            </div>
            <div className="cmd-tile">
              <div className="cmd-tile-label"><span className="ld ld-crit"/>ALERTAS ATIVOS</div>
              <div className="cmd-tile-val crit">7<span className="cmd-tile-delta">▲ 2 / 30min</span></div>
              <Sparkline points={[2,3,3,4,5,5,6,7]} stroke="#FF5A6A" fill width={150} height={24} />
            </div>
            <div className="cmd-tile">
              <div className="cmd-tile-label"><span className="ld ld-stable"/>LEITOS MONITORADOS</div>
              <div className="cmd-tile-val">20<span className="cmd-tile-of">/ 22</span></div>
              <div className="cmd-bars">
                {Array.from({ length: 22 }).map((_, i) => (
                  <span key={i} className={`cmd-bar ${i < 4 ? 'crit' : i < 8 ? 'warn' : i < 20 ? 'on' : 'off'}`}/>
                ))}
              </div>
            </div>
          </div>

          {/* Risk queue */}
          <div className="cmd-queue">
            <div className="cmd-section-head">
              <div className="cmd-section-title">FILA DE RISCO — RHPM</div>
              <div className="cmd-section-actions">
                <span className="seg-mini"><button className="on">Todos</button><button>Alto</button><button>Médio</button></span>
                <span className="live-dot"><i/></span>
              </div>
            </div>
            <div className="cmd-queue-list">
              <PatientRow leito="04" code="J.M.S." level="alto" score={0.91} hours={6} action="ATB sugerido" sparkPoints={[0.2,0.3,0.35,0.5,0.6,0.7,0.82,0.91]} />
              <PatientRow leito="11" code="M.A.R." level="alto" score={0.84} hours={2} action="hemocultura" sparkPoints={[0.3,0.35,0.45,0.5,0.6,0.7,0.75,0.84]} />
              <PatientRow leito="07" code="C.F.L." level="medio" score={0.63} hours={14} action="reavaliar 1h" sparkPoints={[0.4,0.45,0.5,0.55,0.58,0.6,0.62,0.63]} />
              <PatientRow leito="15" code="A.P.B." level="medio" score={0.58} hours={1} action="coleta lactato" sparkPoints={[0.2,0.25,0.3,0.35,0.45,0.5,0.55,0.58]} />
              <PatientRow leito="02" code="R.T.M." level="baixo" score={0.21} hours={48} action="estável" sparkPoints={[0.3,0.28,0.25,0.24,0.22,0.21,0.21,0.21]} />
            </div>
          </div>
        </div>

        <div className="cmd-col-r">
          <Heatmap />
          <ActivityStream />
        </div>
      </div>

      {/* Floating overlay panels — sit ABOVE the dashboard */}
      <div className="float float-tl">
        <div className="float-eyebrow"><span className="ld ld-crit"/>ALERTA CLÍNICO · 14:38</div>
        <div className="float-title">Sepse provável — Leito 04</div>
        <div className="float-body">Score subiu 0.32 nas últimas 6h. Lactato 3.8, FC 124, PAS 88.</div>
        <div className="float-actions">
          <button className="btn btn-primary btn-sm">Acionar plantão</button>
          <button className="btn btn-ghost btn-sm">Ver detalhes</button>
        </div>
      </div>

      <div className="float float-tr">
        <div className="float-gauge">
          <RiskGauge value={score} />
          <div>
            <div className="float-eyebrow">RHPM · Leito 04</div>
            <div className="float-title">Risco preditivo</div>
            <div className="float-tag">↑ tendência ascendente</div>
          </div>
        </div>
      </div>

      <div className="float float-br">
        <div className="float-row">
          <div>
            <div className="float-eyebrow">PRECISÃO PREDITIVA</div>
            <div className="float-bignum">91%</div>
          </div>
          <div className="float-sep"/>
          <div>
            <div className="float-eyebrow">ANTECEDÊNCIA</div>
            <div className="float-bignum cy">6h</div>
          </div>
        </div>
        <Sparkline points={[0.6,0.7,0.65,0.75,0.78,0.82,0.85,0.88,0.91]} stroke="#66E0FF" fill width={220} height={26} />
      </div>
    </div>
  );
};

window.CommandDashboard = CommandDashboard;
