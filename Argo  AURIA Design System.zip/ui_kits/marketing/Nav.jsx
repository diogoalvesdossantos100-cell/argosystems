/* global React */
// Nav.jsx — premium glass nav bar

const NavLink = ({ href, children }) => (
  <a href={href} className="nav-link">{children}<span className="nav-link-underline"/></a>
);

const Nav = () => {
  const [scrolled, setScrolled] = React.useState(false);
  React.useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <nav className={`nav ${scrolled ? 'nav-scrolled' : ''}`}>
      <div className="nav-inner">
        <a href="#" className="nav-logo" aria-label="ARGO Systems">
          {/* ARGO stencil A — institutional mark */}
          <svg viewBox="0 0 56 56" width="24" height="24" aria-hidden="true">
            <g stroke="#F2F3F8" strokeWidth="2.6" strokeLinecap="square" strokeLinejoin="miter" fill="none">
              <path d="M 10 47 L 25.5 12"/>
              <path d="M 30.5 12 L 46 47"/>
              <path d="M 17.5 32 L 38.5 32"/>
            </g>
          </svg>
          <span className="nav-logo-wm">
            <span className="nav-logo-name">ARGO</span>
            <span className="nav-logo-sub">SYSTEMS</span>
          </span>
        </a>

        <div className="nav-center">
          <NavLink href="#nosepsis">NoSepsis</NavLink>
          <NavLink href="#plataforma">Plataforma</NavLink>
          <NavLink href="#sobre">Sobre</NavLink>
          <NavLink href="#contato">Contato</NavLink>
        </div>

        <div className="nav-end">
          <a href="#login" className="nav-link">Entrar</a>
          <a href="#contato" className="btn btn-primary btn-sm nav-cta">Solicitar piloto <span aria-hidden="true">→</span></a>
        </div>
      </div>
    </nav>
  );
};

window.Nav = Nav;
