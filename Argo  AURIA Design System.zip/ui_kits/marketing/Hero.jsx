/* global React, CommandDashboard */
// Hero.jsx — left = headline + CTAs · right = giant CommandDashboard

const Hero = () => {
  const [titleEnd, setTitleEnd] = React.useState('tarde demais.');
  React.useEffect(() => {
    const phrases = ['tarde demais.', 'tempo hábil.'];
    let i = 0, j = 0, deleting = false;
    const tick = () => {
      const target = phrases[i];
      if (!deleting) {
        j++;
        setTitleEnd(target.slice(0, j));
        if (j === target.length) { deleting = true; setTimeout(tick, 2400); return; }
      } else {
        j--;
        setTitleEnd(target.slice(0, j));
        if (j === 0) { deleting = false; i = (i + 1) % phrases.length; }
      }
      setTimeout(tick, deleting ? 50 : 80);
    };
    const initial = setTimeout(tick, 1400);
    return () => clearTimeout(initial);
  }, []);

  return (
    <section className="hero">
      <div className="hero-grid">
        <div className="hero-left">
          <div className="hero-eyebrow eyebrow">
            <span className="dot dot-pulse" style={{ background: '#A892FF', color: '#7C5CFF' }} />
            INTELIGÊNCIA CLÍNICA — UTI · AO VIVO
          </div>

          <h1 className="hero-title">
            Sepse identificada<br/>
            antes que seja<br/>
            <span className="grad">{titleEnd}<span className="caret"/></span>
          </h1>

          <p className="hero-lead">
            A AURIA monitora pacientes críticos em tempo real, prioriza riscos com modelos preditivos e
            entrega alertas acionáveis com horas de antecedência — para que a equipe clínica chegue antes do colapso.
          </p>

          <div className="hero-cta">
            <a href="#contato" className="btn btn-primary btn-lg">
              Solicitar piloto
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
            </a>
            <a href="#nosepsis" className="btn btn-ghost btn-lg">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>
              Ver como funciona
            </a>
          </div>

          <div className="hero-stats">
            <div className="hero-stat">
              <div className="hero-stat-num">91%</div>
              <div className="hero-stat-lbl">precisão preditiva</div>
            </div>
            <div className="hero-stat-sep"/>
            <div className="hero-stat">
              <div className="hero-stat-num">6h</div>
              <div className="hero-stat-lbl">antecedência média</div>
            </div>
            <div className="hero-stat-sep"/>
            <div className="hero-stat">
              <div className="hero-stat-num">30d</div>
              <div className="hero-stat-lbl">para implantação</div>
            </div>
          </div>

          <div className="hero-trust">
            <span className="hero-trust-label">Em uso por</span>
            <div className="hero-trust-logos">
              <span>HOSPITAL SÃO LUCAS</span>
              <span>·</span>
              <span>UTI RIO DOCE</span>
              <span>·</span>
              <span>SC GV</span>
              <span>·</span>
              <span>+4 hospitais MG</span>
            </div>
          </div>
        </div>

        <div className="hero-right">
          <CommandDashboard />
        </div>
      </div>
    </section>
  );
};

window.Hero = Hero;
