/* global React */
// NoSepsisDeep.jsx — deeper feature section on NoSepsis with overlapping dashboard

const FeatureRow = ({ index, title, desc, accent }) => (
  <li className="fl-row">
    <span className="fl-index mono" style={{color: accent}}>{index}</span>
    <div>
      <div className="fl-title">{title}</div>
      <div className="fl-desc">{desc}</div>
    </div>
    <span className="fl-arrow">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
    </span>
  </li>
);

const RadarPanel = () => {
  // ICU operational radar — 5 axes
  const axes = ['Risco', 'Compliance', 'Giro', 'Equipe', 'Alertas'];
  const values = [0.82, 0.65, 0.58, 0.72, 0.78];
  const cx = 120, cy = 120, R = 92;
  const pts = values.map((v, i) => {
    const ang = -Math.PI / 2 + (i / axes.length) * Math.PI * 2;
    return [cx + Math.cos(ang) * R * v, cy + Math.sin(ang) * R * v];
  });
  const poly = pts.map(p => p.join(',')).join(' ');
  return (
    <div className="rad">
      <div className="rad-head">
        <div className="rad-label">RADAR OPERACIONAL · UTI-2A</div>
        <span className="live-dot"><i/></span>
      </div>
      <svg viewBox="0 0 240 240" className="rad-svg">
        {[0.25, 0.5, 0.75, 1].map((r, i) => (
          <polygon key={i} points={axes.map((_, j) => {
            const ang = -Math.PI / 2 + (j / axes.length) * Math.PI * 2;
            return [cx + Math.cos(ang) * R * r, cy + Math.sin(ang) * R * r].join(',');
          }).join(' ')} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="1"/>
        ))}
        {axes.map((a, i) => {
          const ang = -Math.PI / 2 + (i / axes.length) * Math.PI * 2;
          const x = cx + Math.cos(ang) * R;
          const y = cy + Math.sin(ang) * R;
          return <line key={i} x1={cx} y1={cy} x2={x} y2={y} stroke="rgba(255,255,255,0.06)" strokeWidth="1"/>;
        })}
        <polygon points={poly} fill="rgba(124,92,255,0.18)" stroke="#7C5CFF" strokeWidth="1.5" />
        {pts.map((p, i) => <circle key={i} cx={p[0]} cy={p[1]} r="3" fill="#A892FF" stroke="#0F1120" strokeWidth="2"/>)}
        {axes.map((a, i) => {
          const ang = -Math.PI / 2 + (i / axes.length) * Math.PI * 2;
          const x = cx + Math.cos(ang) * (R + 18);
          const y = cy + Math.sin(ang) * (R + 18) + 4;
          return <text key={i} x={x} y={y} textAnchor="middle" fontFamily="Geist Mono, monospace" fontSize="10" fill="rgba(242,243,248,0.55)" style={{letterSpacing:'0.06em'}}>{a.toUpperCase()}</text>;
        })}
      </svg>
    </div>
  );
};

const TimelinePanel = () => {
  const events = [
    { t: '06:00', label: 'Internação', tone: 'neutral' },
    { t: '08:42', label: 'Coleta lab', tone: 'neutral' },
    { t: '10:15', label: 'Score 0.43', tone: 'warn' },
    { t: '12:30', label: 'Score 0.71', tone: 'warn' },
    { t: '14:38', label: 'Score 0.91 · alerta', tone: 'crit' },
    { t: '14:42', label: 'ATB iniciado', tone: 'ok' },
  ];
  return (
    <div className="tl">
      <div className="tl-head">
        <div className="tl-label">TIMELINE CLÍNICA — Leito 04</div>
        <span className="pill pill-violet">+8h</span>
      </div>
      <div className="tl-line">
        {events.map((e, i) => (
          <div key={i} className={`tl-evt tone-${e.tone}`}>
            <span className="tl-dot"/>
            <span className="tl-time mono">{e.t}</span>
            <span className="tl-text">{e.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

const NoSepsisDeep = () => (
  <section id="nosepsis" className="section section-deep">
    <div className="section-inner">
      <div className="deep-grid">
        <div className="deep-left">
          <div className="eyebrow"><span className="dot dot-pulse" style={{background:'#A892FF', color:'#7C5CFF'}}/>FLAGSHIP · NOSEPSIS</div>
          <h2 className="section-title">Alerta inteligente para UTI.<br/><span className="grad">Antes que o quadro vire crítico.</span></h2>
          <p className="section-lead">Modelos preditivos validados com dados reais de pacientes brasileiros. RHPM — <em>Risk Heat &amp; Prioritization Model</em> — ranqueia cada leito em tempo real e sugere a próxima ação clínica.</p>

          <ul className="feature-list">
            <FeatureRow index="01" title="Fila de risco priorizada (RHPM)" accent="#A892FF"
              desc="Todos os pacientes ranqueados por gravidade em tempo real. A equipe sabe exatamente quem atender primeiro." />
            <FeatureRow index="02" title="Alertas clínicos acionáveis" accent="#A892FF"
              desc="Não é só um score — o sistema sugere a próxima ação: ATB, coleta de hemocultura, avaliação médica urgente." />
            <FeatureRow index="03" title="Relatório executivo para diretoria" accent="#66E0FF"
              desc="Dashboard NoMaster com indicadores de sepse, compliance e impacto financeiro evitado por internação." />
            <FeatureRow index="04" title="Implantação em 30 dias" accent="#66E0FF"
              desc="Piloto em UTI com resultado mensurável no primeiro mês. Sem grandes integrações ou mudanças de fluxo." />
          </ul>

          <div className="deep-cta">
            <a href="#contato" className="btn btn-primary btn-lg">Solicitar piloto <span aria-hidden="true">→</span></a>
            <a href="#" className="btn btn-ghost btn-lg">Baixar white paper RHPM</a>
          </div>
        </div>

        <div className="deep-right">
          <div className="deep-stack">
            <RadarPanel/>
            <TimelinePanel/>
            <div className="float float-deep">
              <div className="float-eyebrow"><span className="ld ld-crit"/>SCORE LEITO 04</div>
              <div style={{display:'flex',alignItems:'center',gap:14, marginTop:8}}>
                <div className="float-bignum crit">0.91</div>
                <div>
                  <div className="float-tag" style={{color:'#FF8E99'}}>↑ 0.06 em 1h</div>
                  <div className="float-tag" style={{color:'rgba(242,243,248,0.55)', marginTop:2}}>antecedência: 6h</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

window.NoSepsisDeep = NoSepsisDeep;
