/* global React */
// Footer.jsx

const Footer = () => (
  <footer className="footer">
    <div className="footer-inner">
      <div className="footer-l">
        <div className="footer-logo">
          <svg viewBox="0 0 56 56" width="32" height="32" aria-hidden="true">
            <g stroke="#F2F3F8" strokeWidth="2.6" strokeLinecap="square" strokeLinejoin="miter" fill="none">
              <path d="M 10 47 L 25.5 12"/>
              <path d="M 30.5 12 L 46 47"/>
              <path d="M 17.5 32 L 38.5 32"/>
            </g>
          </svg>
          <span className="footer-logo-wm">
            <span className="footer-logo-name">ARGO</span>
            <span className="footer-logo-sub">SYSTEMS</span>
          </span>
        </div>
        <p className="footer-tag">Infraestrutura operacional crítica para sistemas hospitalares modernos. Plataforma AURIA.</p>
      </div>

      <div className="footer-cols">
        <div className="footer-col">
          <div className="footer-col-h">Plataforma</div>
          <a>NoSepsis</a><a>NoPAV</a><a>NoDelirium</a><a>NoReação</a><a>NoMaster</a>
        </div>
        <div className="footer-col">
          <div className="footer-col-h">Empresa</div>
          <a>Sobre</a><a>Blog clínico</a><a>White papers</a><a>Imprensa</a><a>Carreiras</a>
        </div>
        <div className="footer-col">
          <div className="footer-col-h">Contato</div>
          <a href="mailto:diogojustino@argosystems.com.br">diogojustino@argosystems.com.br</a>
          <a href="mailto:contato@argosystems.com.br">contato@argosystems.com.br</a>
          <a>WhatsApp · (33) 99100-0048</a>
          <a>Governador Valadares · MG</a>
        </div>
      </div>
    </div>
    <div className="footer-bottom">
      <div className="footer-bottom-l">© 2026 Argo Systems · CNPJ 22.896.339/0001-50</div>
      <div className="footer-bottom-r">
        <span className="footer-badge">LGPD</span>
        <span className="footer-badge">CFM</span>
        <span className="footer-badge">COFEN</span>
        <span className="footer-badge">ISO 27001 (em implantação)</span>
      </div>
    </div>
  </footer>
);

window.Footer = Footer;
