/* global React */
// OperationalNumbers.jsx — strip of 4 big metrics under hero

const COUNTER = ({ to, suffix = '', prefix = '', decimals = 0, duration = 1600 }) => {
  const [val, setVal] = React.useState(0);
  const ref = React.useRef(null);
  React.useEffect(() => {
    let raf;
    const io = new IntersectionObserver(entries => {
      entries.forEach(e => {
        if (e.isIntersecting) {
          const start = performance.now();
          const step = (now) => {
            const t = Math.min(1, (now - start) / duration);
            const ease = 1 - Math.pow(1 - t, 3);
            setVal(to * ease);
            if (t < 1) raf = requestAnimationFrame(step);
          };
          raf = requestAnimationFrame(step);
          io.disconnect();
        }
      });
    }, { threshold: 0.4 });
    if (ref.current) io.observe(ref.current);
    return () => { cancelAnimationFrame(raf); io.disconnect(); };
  }, [to, duration]);
  return <span ref={ref}>{prefix}{val.toFixed(decimals)}{suffix}</span>;
};

const OperationalNumbers = () => {
  const items = [
    { val: 30, suffix: '%', label: 'mortalidade da sepse grave' },
    { val: 6, suffix: 'h', label: 'janela crítica de intervenção' },
    { val: 72, suffix: '%', label: 'sinais precoces ignorados' },
    { prefix: 'R$', val: 18, suffix: 'k', label: 'custo médio por internação grave' },
  ];
  return (
    <section className="opnums">
      <div className="opnums-inner">
        {items.map((n, i) => (
          <React.Fragment key={i}>
            <div className="opnum">
              <div className="opnum-val grad-aurora">
                <COUNTER to={n.val} prefix={n.prefix || ''} suffix={n.suffix} />
              </div>
              <div className="opnum-lbl">{n.label}</div>
            </div>
            {i < items.length - 1 && <div className="opnum-sep"/>}
          </React.Fragment>
        ))}
      </div>
    </section>
  );
};

window.OperationalNumbers = OperationalNumbers;
