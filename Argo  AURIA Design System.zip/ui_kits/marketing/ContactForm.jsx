/* global React */
// ContactForm.jsx — glass card with halo glow, real form fields

const ContactForm = () => {
  const [sent, setSent] = React.useState(false);
  const onSubmit = (e) => { e.preventDefault(); setSent(true); };

  return (
    <section id="contato" className="section section-contact">
      <div className="section-inner contact-inner">
        <header className="section-head" style={{textAlign:'center'}}>
          <div className="eyebrow" style={{justifyContent:'center'}}><span className="dot dot-pulse" style={{background:'#66E0FF', color:'#66E0FF'}}/>CONTATO</div>
          <h2 className="section-title" style={{textAlign:'center'}}>Pronto para um <span className="grad">piloto?</span></h2>
          <p className="section-lead" style={{margin:'12px auto 0'}}>Atendemos pessoalmente cada solicitação — sem call center, sem formulário genérico. Resposta em até 24h úteis.</p>
        </header>

        <form className="contact-card glass" onSubmit={onSubmit}>
          <div className="contact-halo"/>
          <div className="contact-row">
            <label>
              <span className="contact-lbl">Nome completo</span>
              <input className="contact-ipt" required placeholder="Dr. João Silva"/>
            </label>
            <label>
              <span className="contact-lbl">Hospital / Instituição</span>
              <input className="contact-ipt" required placeholder="Hospital São Lucas"/>
            </label>
          </div>
          <div className="contact-row">
            <label>
              <span className="contact-lbl">Cargo</span>
              <select className="contact-ipt" required defaultValue="">
                <option value="" disabled>Selecione…</option>
                <option>Diretor Clínico</option>
                <option>Diretor Administrativo</option>
                <option>Médico Intensivista</option>
                <option>Gerente de Qualidade</option>
                <option>Outro</option>
              </select>
            </label>
            <label>
              <span className="contact-lbl">WhatsApp</span>
              <input className="contact-ipt" type="tel" required placeholder="(33) 99999-0000"/>
            </label>
          </div>
          <label className="contact-full">
            <span className="contact-lbl">E-mail institucional</span>
            <input className="contact-ipt" type="email" required placeholder="joao@hospital.com.br"/>
          </label>
          <label className="contact-full">
            <span className="contact-lbl">Mensagem <em style={{color:'var(--text-3)', fontStyle:'normal'}}>(opcional)</em></span>
            <textarea className="contact-ipt contact-ta" placeholder="Tamanho da UTI, dúvidas, disponibilidade…"/>
          </label>
          <button type="submit" className="btn btn-primary btn-lg contact-submit">
            {sent ? '✓ Mensagem recebida — retornaremos em 24h' : 'Solicitar contato →'}
          </button>
          <div className="contact-meta">
            <span>🔒 LGPD compliant</span>
            <span>·</span>
            <span>Dados não compartilhados</span>
            <span>·</span>
            <span>Resposta em até 24h úteis</span>
          </div>
        </form>
      </div>
    </section>
  );
};

window.ContactForm = ContactForm;
