/* global React */
// ModuleGrid.jsx — AURIA platform modules grid with custom monoline glyphs

// Inline glyphs (stroked, currentColor) so they can be styled live
const Glyph = ({ name }) => {
  const s = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.6, strokeLinecap: 'round', strokeLinejoin: 'round' };
  switch (name) {
    case 'nosepsis': return (
      <svg viewBox="0 0 24 24" width="22" height="22" {...s}>
        <path d="M2 12 H6 L8 6 L11 18 L13 9 L15 14 L18 12 H22" />
        <circle cx="18" cy="12" r="2.2" />
      </svg>);
    case 'nopav': return (
      <svg viewBox="0 0 24 24" width="22" height="22" {...s}>
        <path d="M12 4 V14" />
        <path d="M12 8 C8 8 5 10 5 14 C5 18 7 20 9 20 C11 20 12 19 12 16" />
        <path d="M12 8 C16 8 19 10 19 14 C19 18 17 20 15 20 C13 20 12 19 12 16" />
      </svg>);
    case 'nodelirium': return (
      <svg viewBox="0 0 24 24" width="22" height="22" {...s}>
        <path d="M3 12 H6 L7 9 L8 15 L9 11 L10 13" />
        <path d="M11 7 C13 5 17 5 19 8 C21 11 20 14 18 16 C19 18 18 20 16 20 C14 20 13 18 13 16" />
      </svg>);
    case 'noreacao': return (
      <svg viewBox="0 0 24 24" width="22" height="22" {...s}>
        <path d="M9 3 H15 V6 L17 8 V18 C17 20 15 21 13 21 H11 C9 21 7 20 7 18 V8 L9 6 Z" />
        <path d="M12 11 C12 11 10 14 10 16 C10 17.5 11 18.5 12 18.5 C13 18.5 14 17.5 14 16 C14 14 12 11 12 11 Z" fill="currentColor" stroke="none" opacity="0.5"/>
      </svg>);
    case 'leito': return (
      <svg viewBox="0 0 24 24" width="22" height="22" {...s}>
        <path d="M3 18 V10 H13 V14 H21 V18" />
        <path d="M3 20 H21" />
        <circle cx="7" cy="13" r="1.4" />
      </svg>);
    case 'escala': return (
      <svg viewBox="0 0 24 24" width="22" height="22" {...s}>
        <rect x="3" y="5" width="18" height="16" rx="2" />
        <path d="M3 10 H21" />
        <path d="M8 3 V7 M16 3 V7" />
        <circle cx="9" cy="15" r="1.4" /><circle cx="15" cy="15" r="1.4" />
      </svg>);
    case 'nomaster': return (
      <svg viewBox="0 0 24 24" width="22" height="22" {...s}>
        <rect x="3" y="3" width="8" height="10" rx="1" />
        <rect x="13" y="3" width="8" height="6" rx="1" />
        <rect x="3" y="15" width="8" height="6" rx="1" />
        <rect x="13" y="11" width="8" height="10" rx="1" />
      </svg>);
    default: return null;
  }
};

const ModuleCard = ({ glyph, name, status, desc, accent, active, featured }) => (
  <article className={`mc ${featured ? 'mc-featured' : ''} ${active ? 'mc-active' : ''}`}>
    <header className="mc-head">
      <span className="mc-icon" style={{color: accent}}>
        <Glyph name={glyph}/>
      </span>
      <span className={`pill ${active ? 'pill-violet' : 'pill-neutral'}`}>{status}</span>
    </header>
    <h3 className="mc-name">{name}</h3>
    <p className="mc-desc">{desc}</p>
    <footer className="mc-foot">
      <span className="mc-link">Explorar módulo
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
      </span>
    </footer>
  </article>
);

const ModuleGrid = () => (
  <section id="plataforma" className="section section-modules">
    <div className="section-inner">
      <header className="section-head">
        <div className="eyebrow"><span className="dot dot-pulse" style={{ background:'#66E0FF', color:'#66E0FF' }}/>PLATAFORMA AURIA</div>
        <h2 className="section-title">Um ecossistema de <span className="grad">inteligência clínica</span><br/>nascido dentro da UTI.</h2>
        <p className="section-lead">Sete módulos operacionais. Um único centro de comando. A AURIA é a primeira plataforma brasileira de <em>predictive ICU intelligence</em> — modular, auditável e implantada em 30 dias.</p>
      </header>

      <div className="modules-grid">
        <ModuleCard featured active glyph="nosepsis" name="NoSepsis" status="FLAGSHIP · ATIVO" accent="#A892FF"
          desc="Detecção precoce de sepse na UTI. Fila de risco priorizada (RHPM), alertas clínicos acionáveis e relatório executivo em tempo real."/>
        <ModuleCard active glyph="nopav" name="NoPAV" status="ATIVO" accent="#66E0FF"
          desc="Prevenção de pneumonia associada à ventilação mecânica. Monitora bundles de cuidado e dispara alertas de não-conformidade."/>
        <ModuleCard active glyph="nodelirium" name="NoDelirium" status="ATIVO" accent="#A892FF"
          desc="Rastreio contínuo de delirium em pacientes críticos. Escalas (CAM-ICU, RASS) automatizadas e alertas para reavaliação médica."/>
        <ModuleCard active glyph="noreacao" name="NoReação" status="ATIVO" accent="#FF8E99"
          desc="Monitoramento de reações transfusionais em tempo real. Identifica sinais adversos durante e após a transfusão."/>
        <ModuleCard active glyph="leito" name="Gestão de Leito" status="ATIVO" accent="#66E0FF"
          desc="Painel de ocupação, giro e disponibilidade de leitos em tempo real. Reduz tempo médio de espera por internação."/>
        <ModuleCard active glyph="escala" name="Escala de Enfermagem" status="ATIVO" accent="#A892FF"
          desc="Dimensionamento inteligente de equipe por turno e complexidade dos pacientes. Conformidade COFEN automática."/>
        <ModuleCard active glyph="nomaster" name="NoMaster" status="ATIVO" accent="#66E0FF"
          desc="Painel executivo consolidando todos os módulos AURIA. Indicadores de qualidade, segurança e impacto financeiro."/>
      </div>
    </div>
  </section>
);

window.ModuleGrid = ModuleGrid;
window.Glyph = Glyph;
