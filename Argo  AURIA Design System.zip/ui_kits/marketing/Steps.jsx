/* global React */
// Steps.jsx — process: 4 steps from contact to first impact report

const STEPS = [
  { n: '01', title: 'Reunião de diagnóstico', desc: 'Mapeamos o fluxo da UTI, o volume de pacientes e os dados disponíveis. Sem compromisso.' },
  { n: '02', title: 'Proposta personalizada', desc: 'Projeto piloto com escopo, investimento e indicadores de sucesso definidos antes de começar.' },
  { n: '03', title: 'Implantação em 30 dias', desc: 'Sistema operacional na UTI com treinamento da equipe, suporte contínuo e painel ao vivo.' },
  { n: '04', title: 'Relatório de impacto', desc: 'Análise de casos detectados, alertas disparados e custo evitado ao final do piloto.' },
];

const Steps = () => (
  <section id="processo" className="section section-steps">
    <div className="section-inner">
      <header className="section-head">
        <div className="eyebrow"><span className="dot dot-pulse" style={{background:'#A892FF', color:'#7C5CFF'}}/>PROCESSO</div>
        <h2 className="section-title">Do contato à <span className="grad">primeira UTI</span><br/>monitorada — 30 dias.</h2>
      </header>
      <div className="steps-track">
        <div className="steps-line"/>
        {STEPS.map((s, i) => (
          <div key={i} className="step" style={{transitionDelay: `${i * 100}ms`}}>
            <div className="step-num">{s.n}</div>
            <div className="step-title">{s.title}</div>
            <div className="step-desc">{s.desc}</div>
          </div>
        ))}
      </div>
    </div>
  </section>
);

window.Steps = Steps;
